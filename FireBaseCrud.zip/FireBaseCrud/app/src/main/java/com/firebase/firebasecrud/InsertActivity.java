package com.firebase.firebasecrud;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.firebasecrud.model.MusicaVO;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class InsertActivity extends AppCompatActivity {
private EditText txtN, txtAlb, txtArt, txtGen;

//variables para la interaccion de la BD
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        txtN = findViewById(R.id.nameTxt);
        txtAlb = findViewById(R.id.albumTxt);
        txtArt = findViewById(R.id.artistTxt);
        txtGen = findViewById(R.id.genereTxt);
        iniciarFirebase();
    }

    public void onClick(View view) {
        insert();
    }

    private void iniciarFirebase(){
        FirebaseApp.initializeApp(getApplicationContext());
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    private void insert(){

        MusicaVO mvo = new MusicaVO();
        if (!txtN.getText().toString().isEmpty()&&
                !txtAlb.getText().toString().isEmpty()&&
                !txtArt.getText().toString().isEmpty()&&
                !txtGen.getText().toString().isEmpty()){

            mvo.setId(UUID.randomUUID().toString());
            mvo.setNombre(txtN.getText().toString());
            mvo.setAlbum(txtAlb.getText().toString());
            mvo.setArtista(txtArt.getText().toString());
            mvo.setGenero(txtGen.getText().toString());

            //Creacion del nodo o tabla con sus clave-valor referentes en Firebase
            databaseReference.child("Musica").child(mvo.getId()).setValue(mvo);
            txtN.setText("");
            txtAlb.setText("");
            txtArt.setText("");
            txtGen.setText("");
            Toast.makeText(this, "Datos ingresados", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Datos no ingresados", Toast.LENGTH_SHORT).show();
        }
    }
}
